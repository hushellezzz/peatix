Build and Deploy
Screenshots are shown in deploy folder

1. Download Eclipse and Import the temperature project, show in (step1.png, step2.png)
2. From the menu click Run (step3.png)
3. Spring booting up will be shown in the logs (step4.png)
4. Call the API from the browser (step5.png)


Test cases
Screenshots of API calls are shown in sample folder

1. Celsius to Fahrenheit Negative Input
   GET http://localhost:8080/convert-temperature/celsius-to-fahrenheit/-50
   
2. Celsius to Fahrenheit Zero Input
   GET http://localhost:8080/convert-temperature/celsius-to-fahrenheit/0
   
3. Celsius to Fahrenheit Positive Input
   GET http://localhost:8080/convert-temperature/celsius-to-fahrenheit/30
   
4. Fahrenheit to Celsius
   GET http://localhost:8080/convert-temperature/fahrenheit-to-celsius/100
   
5. Invalid API call
   GET http://localhost:8080/convert/fahrenheit-to-celsius/100

6. Invalid Input parameter
   GET http://localhost:8080/convert-temperature/celsius-to-fahrenheit/A