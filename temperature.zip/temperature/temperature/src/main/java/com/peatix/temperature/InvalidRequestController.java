package com.peatix.temperature;

import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.peatix.model.Result;

@RestController
public class InvalidRequestController implements ErrorController {
	@RequestMapping("/error")
    public Result handleError() {
        return new Result(0, Result.INVALID_REQUEST);
    }
}
