package com.peatix.model;


public class Result {
	public static String SUCCESS_F = "Conversion to Fahrenheit successful.";
	public static String SUCCESS_C = "Conversion to Celsius successful.";
	public static String INVALID_INPUT = "Invalid Input.";
	public static String INVALID_REQUEST = "Invalid Request.";
	private double output;
	private String message;
	
	public Result(double output, String message) {
		this.output = output;
		this.message = message;
	}

	public double getOutput() {
		return output;
	}

	public void setOutput(double output) {
		this.output = output;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	
}
