package com.peatix.temperature;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

import com.peatix.model.Result;

@RestController
public class TemperatureController {

	// to-fahrenheit
	@GetMapping(value = "/convert-temperature/celsius-to-fahrenheit/{temperature}", 
			  produces = MediaType.APPLICATION_JSON_VALUE)
	public Result toFahrenheit( @PathVariable("temperature") double temperature) {
		return new Result(temperature*9/5 + 32, Result.SUCCESS_F);
	}
	
	// to-celsius
	@GetMapping(value = "/convert-temperature/fahrenheit-to-celsius/{temperature}", 
			  produces = MediaType.APPLICATION_JSON_VALUE)
	public Result toCelsius( @PathVariable("temperature") double temperature) {
		return new Result((temperature-32)*5/9 , Result.SUCCESS_C);
	}
	
	@ExceptionHandler(MethodArgumentTypeMismatchException.class)
	public Result invalidInput(MethodArgumentTypeMismatchException ex) {
	    return new Result(0, Result.INVALID_INPUT);
	}

}