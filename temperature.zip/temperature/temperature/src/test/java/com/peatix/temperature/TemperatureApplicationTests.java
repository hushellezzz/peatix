package com.peatix.temperature;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TemperatureApplicationTests {

	@Test
	void contextLoads() {
	}

}
